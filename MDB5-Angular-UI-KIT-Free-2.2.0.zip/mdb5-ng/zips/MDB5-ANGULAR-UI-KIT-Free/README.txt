MDB 5 Angular

Version: FREE 2.2.0

Documentation:
https://mdbootstrap.com/docs/b5/angular/

Installation:
https://mdbootstrap.com/docs/b5/angular/getting-started/installation/

CLI & hosting:
https://mdbootstrap.com/docs/standard/cli/

Support:
https://mdbootstrap.com/support/cat/angular/
